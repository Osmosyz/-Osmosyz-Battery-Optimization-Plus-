#!/system/bin/sh
# Forzar Doze temprano
dumpsys deviceidle force-idle

# Limitar apps activas
settings put global app_standby_enabled 1
settings put global force_app_standby 1
settings put global background_data 0
